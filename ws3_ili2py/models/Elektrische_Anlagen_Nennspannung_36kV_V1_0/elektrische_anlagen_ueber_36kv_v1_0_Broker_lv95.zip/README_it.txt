Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Impianti elettrici con una tensione nominale superiore a 36 kV
Ciclo di aggiornamento:
    Continuo
Stato attuale (ultima pubblicazione):
    28.07.2025 02:08:40
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    No
Osservazioni:
    Si tratta di un servizio fornito dall'Ufficio federale dell'energia in collaborazione con i gestori degli impianti. Lo sviluppo dell'offerta su www.geodienste.ch è stato sostenuto dall'attuazione della Strategia svizzera di geoinformazione. Maggiori informazioni su https://www.bfe.admin.ch/alineamenti
Contatto:
    nessuna indicazione
