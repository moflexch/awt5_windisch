Detailinformationen Kanton 
---------------------------

Thema:
    Elektrische Anlagen mit einer Nennspannung von über 36 kV
Aktualisierungs-Zyklus:
    Laufend
Zeitstand (letzte Publikation):
    28.07.2025 02:08:40
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    Dies ist ein Angebot des Bundesamtes für Energie in Zusammenarbeit mit den Werksbetreibern. Der Aufbau des Angebots auf www.geodienste.ch wurde unterstützt durch die Umsetzung der Strategie Geoinformation Schweiz. Mehr Informationen auf https://www.bfe.admin.ch/elektrische-anlagen
Kontakt:
    keine Angabe
