Informations détaillées du canton 
----------------------------------

Thème:
    Installations électriques d’une tension nominale supérieure à 36 kV
Cycle de mise à jour:
    en permanence
Date de dernière publication:
    28.07.2025 02:08:40
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Non
Remarques:
    Il s'agit d'une offre de l'Office fédéral de l'énergie en collaboration avec les exploitants d'usines. La mise en place de l'offre sur www.geodienste.ch a été soutenue par la mise en œuvre de la stratégie suisse pour l'information géographique. Plus d'informations sur https://www.bfe.admin.ch/alignements
Contact:
    aucune indication
